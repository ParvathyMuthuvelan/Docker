CREATE TABLE IF NOT EXISTS rating (
  ratingId int primary key,movie_Id VARCHAR(50),userid varchar(20),rating int);
  insert into rating values(1,'M1','User1',8);
  insert into rating values(2,'M1','User2',7);
  insert into rating values(3,'M2','User1',7);