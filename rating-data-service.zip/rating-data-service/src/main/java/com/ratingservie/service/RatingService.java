package com.ratingservie.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ratingservice.dao.RatingRepository;
import com.ratingservice.model.Rating;

@Service
public class RatingService {
	@Autowired
	RatingRepository ratingRepository;

	@Transactional
	public List<Rating> getRating(String movieId) {
		List<Rating> ratingList=new ArrayList<Rating>();
		ratingList=ratingRepository.getRating(movieId);
//		if(rating.isPresent())
//			obj=rating.get();
		return ratingList;
	}
@Transactional
	public List<Rating> getUserRatings(String userId) {
	List<Rating> ratings=ratingRepository.getUserRatings(userId);
	System.out.println("ratings list in service="+ratings);
		return ratings;
	}

}
